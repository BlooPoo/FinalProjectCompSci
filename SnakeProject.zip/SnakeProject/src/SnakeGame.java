
public class SnakeGame {

	public static void main(String[] args) {
		//create a new instance of the game and call its run() method.

		Game game = new Game();
		game.run();
	}

}
